<?php
/**
 * Title: old-header
 * Slug: old-header
 * Categories: headers
 */
?>	


<!--div class="menu from-wordpress">  
	<ul>
		<li class="page_item page-item-27"><a href="http://untouchedcocktails.com/everyday-cocktails/">Everyday Cocktails</a></li>
		<li class="page_item page-item-25"><a href="http://untouchedcocktails.com/fireplace-cocktails/">Fireplace Cocktails</a></li>
		<li class="page_item page-item-29"><a href="http://untouchedcocktails.com/romantic-cocktails/">Romantic Cocktails</a></li>
		<li class="page_item page-item-32"><a href="http://untouchedcocktails.com/special-occasion-cocktails/">Special Occasion Cocktails</a></li>
		<li class="page_item page-item-34"><a href="http://untouchedcocktails.com/springtime-cocktails/">Springtime Cocktails</a></li>
		<li class="page_item page-item-36"><a href="http://untouchedcocktails.com/summertime-cocktails/">Summertime Cocktails</a></li>
	</ul>
</div>
<div--> 


<!-- NAVIGATION MENU  -->
	<nav class = "topnav">
				
	<a class="icon"href="http://untouchedcocktails.com/">
		<figure>
			<img src = "http://untouchedcocktails.com/wp-content/uploads/2024/09/logo.jpg" />
		</figure>
		</a>
		
		<div class="write-over">
			<p id="size-this"> 
				UntouchedCocktails.com © 2024   </p>
			<p id="size-this">
				information@untouchedcocktails.com    </p>
			<p id="size-this"> 
				# (617) 759-2057    </p>
		</div>



				
				<div id = "tierOne">
					<a href="http://untouchedcocktails.com/fireplace-cocktails/" class="page">Fireplace Cocktails</a>
					<a href="http://untouchedcocktails.com/special-occasion-cocktails/" class="page">Special Occasion Cocktails</a>
					<a href="http://untouchedcocktails.com/everyday-cocktails/" class="page">EveryDay Cocktails</a>
					<a href="http://untouchedcocktails.com/autumnal-cocktails/" class="page">Seasonal Cocktails</a>
					<a href="http://untouchedcocktails.com/romantic-cocktails/" class="page">Romantic Cocktails</a>
					<a href="http://untouchedcocktails.com/contact-us/" class="page">Learn More</a>
					<a href="http://untouchedcocktails.com" class="page">Home Page</a>
					<a href="http://untouchedcocktails.com/an_gallery/" class="page">Gallery</a>
					<a href ="" class="page">Blog</a>
				</div>


			
			<!-- "Hamburger menu" / "Bar icon" to toggle the navigation links -->
			<a class="hamburgler" onclick="myFunction()">
				<div class ="hamburger">	</div>
			</a> 
	</nav>















