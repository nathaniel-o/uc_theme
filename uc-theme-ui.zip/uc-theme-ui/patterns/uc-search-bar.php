
<?php
/**
 * Title: UC Search Bar
 * Slug: uc-search-bar
 * Categories: Featured
*/
?>
<!-- Pattern code goes here. -->



<form role="search" method="get" action="http://localhost/wordpress/" class="wp-block-search__button-outside wp-block-search__text-button aligncenter wp-block-search">
<label class="wp-block-search__label screen-reader-text" for="wp-block-search__input-2">Search
</label>
<div class="wp-block-search__inside-wrapper ">
<input class="wp-block-search__input" id="wp-block-search__input-2" placeholder="" value="" type="search" name="s" required="">
<button aria-label="Search" class="wp-block-search__button wp-element-button" type="submit">Search
</button>
</div>
</form>