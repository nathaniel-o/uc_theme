<?php
/**
 * Title: old-index-main
 * Slug: old-index-main
 * Categories: featured
 * 
 * 
 */
?>	
<!-- Pattern code goes here. -->



<div class="tier-one home">
			
	<div class = "contains">		
		<section class = vertUne>	
				
			<figure class = "home-figure landscape">
				<img  src = "http://untouchedcocktails.com/wp-content/uploads/2024/09/Pair-of-Fireplace-Drinks_FP-T-scaled.jpg" 
						alt = "Pair of Fireplace Drinks" 
						title = "Pair of Fireplace Drinks" />
				<figcaption>Fireplace Cocktails</figcaption>
			</figure>
				
			<h2 class = "quote quoteThree " >"But a cocktail is not only a visual pleasure,<br></br> it must
				also be delicious.<br></br>Every drink on our website
				was <br></br>crafted for someone <br></br>specific, blended for the<br></br>
				perfect balance,<br></br> every sip to be savored."
			</h2>				
				
			<figure class = "home-figure portrait" id="foto-deux">
				<img src = "http://untouchedcocktails.com/wp-content/uploads/2024/09/Ginger-Peach-n-Scotch_AU-T-rotated.jpg" 
					alt = "Ginger Peach n' Scotch Autumnal Cocktail"
					title = "Ginger Peach n' Scotch Autumnal Cocktail" />
				<figcaption>Seasonal Cocktails</figcaption>
			</figure>
			
	</section><hr>
				
	<section class = "vertDeux">
				
		<figure class = "home-figure portrait">
			<img src = "http://untouchedcocktails.com/wp-content/uploads/2024/09/Holiday-Old-Fashioned-and-Kir-Royale_SO-T.jpg" 
				alt = "Holiday Old Fashioned and Kir Royale"
				title = "Holiday Old Fashioned and Kir Royale" />
			<figcaption>Special Occasion Cocktails</figcaption>
		</figure>
			
				
				
			
				
		<figure class = "home-figure portrait" id="foto-quatre">
			<img src ="http://untouchedcocktails.com/wp-content/uploads/2024/09/Citrus-Gimlet-with-Butterfly-Pea-Flower-Float_EV-T.jpg" 
				alt = "Citrus Gimlet with Butterfly Pea Flower Float Everyday Cocktail" 
				title = "Citrus Gimlet with Butterfly Pea Flower Float Everyday Cocktail" />
			<figcaption>Everyday Cocktails</figcaption>
		</figure>
					
	</section><hr>		
				
		
	<section class = "vertTrois">
				
				<figure class = "home-figure portrait" id="foto-last">
				<img src = "http://untouchedcocktails.com/wp-content/uploads/2024/09/Cranberry-Citrus-Dragon_RO-T.jpg"
					alt = "Cranberry Citrus Dragon Romantic Cocktail"
					title = "Cranberry Citrus Dragon Romantic Cocktail" />
				<figcaption>Romantic Cocktails</figcaption>
				</figure>
						
				
				
				<a href ="http://untouchedcocktails.com/contact-us/">
					<button name = "" type="" class="std-button" form=""
						formmethod ="" action = "" > Learn More </button>
				</a>
				
				
			
	</section><hr>
</div>

</div>
				
